﻿/*
Author: LTDesigns
Date: 4/9/2017
Purpose: This script is used to activate and deactivate gravity on a gameObject.
*/

using UnityEngine;
using System.Collections;

public class Gravity : MonoBehaviour {

    private Rigidbody rb;

    // Use this for initialization
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void EnableGravity()
    {
            rb.useGravity = false;
    }

     public void DisableGravity()
    {
            rb.useGravity = true;
    }
}
