﻿using UnityEngine;
using System.Collections;

public class Fireball : MonoBehaviour {

    [SerializeField]
    private float appliedThrust = 0.5f;
    public GameObject explosionPrefab;
    private Rigidbody rb;
    private Vector3 direction;

	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody>(); //Grab our rigidbody
        direction = new Vector3(0, 2, 15); //What direction we will send our fireball, 1 up, 1 forward
        rb.AddForce(transform.TransformDirection(direction) * appliedThrust); //Apply our Thrust to our Rigidbody in our direction
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag != "Fireball")
        {
            Instantiate(explosionPrefab, transform.position, transform.rotation); //Instantiate an explosive prefab
            Destroy(gameObject); //Destroy this fireball
        }
    }
}
