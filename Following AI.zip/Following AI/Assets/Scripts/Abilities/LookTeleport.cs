﻿using UnityEngine;
using System.Collections;
using UnityEngine.Events;

[System.Serializable]
public class ToggleEvent : UnityEvent<bool>
{

}
public class LookTeleport : MonoBehaviour {

    private RaycastHit lastRaycastHit;
    public AudioClip teleportEffect;
    [SerializeField]
    private float range = 1000.0f;
    [SerializeField]
    private ParticleSystem teleportFX;

    // Use this for initialization
    void Start () {
        
	}

    //Find out what we are looking at
    private GameObject GetLookedAtObject()
    {
        //Create a Raycast
        Vector3 origin = transform.position;
        Vector3 direction = Camera.main.transform.forward;
        //If we hit something
        if (Physics.Raycast(origin, direction, out lastRaycastHit, range))
        {
            //If we hit something, return the object
            return lastRaycastHit.collider.gameObject;
        }
        else
        {
            //If we don't hit anything, don't do anything
            return null;
        }
    }

    //Now we need to teleport
    private void TeleportToLookDirection()
    {
        //teleportFX.Play();
        //Put out position to where the Raycast hit point is
        transform.position = lastRaycastHit.point + lastRaycastHit.normal * 2;
        //If we have an audio clip attached
        if (teleportEffect != null)
            //Play the audio clip
            AudioSource.PlayClipAtPoint(teleportEffect, transform.position);
    }
	// Update is called once per frame
	public void Teleport () {        
        //If we are looking at an object
            if (GetLookedAtObject() != null)
            {
            //Teleport to where we are looking
                TeleportToLookDirection();
            }        
	}
}
