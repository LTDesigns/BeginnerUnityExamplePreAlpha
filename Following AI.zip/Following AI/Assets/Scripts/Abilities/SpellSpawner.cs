﻿using UnityEngine;
using System.Collections;

public class SpellSpawner : MonoBehaviour {

    public GameObject fireballPrefab; //We need to be able to tell our script what item to spawn in the game
    private bool canShoot; //We set a bool to let our engine know if we are able to shoot or not

	// Use this for initialization
	void Start () {
        //When starting the game, our character should be able to shoot
        canShoot = true;
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public void Fireball()
    {
        //If the player is able to shoot
        if (canShoot == true)
        {
            //Start our Coroutine, we use a Coroutine so we can prevent the player from shooting rapidly
            StartCoroutine(FireballDelay());            
        }
        else
        {
            //If we can't shoot, we return to the top to try the procedure over again
            return;
        }
    }

    //We need a way to prevent the player from constantly spamming fireballs
    private IEnumerator FireballDelay()
    {       
        canShoot = false; //Tell our engine that the player can no longer shoot
        yield return new WaitForSeconds(1.5f); //Wait for 1.5 seconds in order to line up our animation and fireball spawn
        //This also keeps the player from fireing for 1.5 seconds
        Instantiate(fireballPrefab, transform.position, transform.rotation); //Spawn a fireball
        canShoot = true; //Tell our engine that the player is able to shoot again
    }
}
