﻿using UnityEngine;
using System.Collections;

public class SlowMotion : MonoBehaviour {

    [SerializeField]
    private float slowdownFactor = 0.05f;
    [SerializeField]
    private float slowdownLength = 2.0f;

    private void Start()
    {
    }
    private void Update()
    {
        Time.timeScale += (1.0f / slowdownLength) * Time.unscaledDeltaTime;
        Time.timeScale = Mathf.Clamp(Time.timeScale, 0.0f, 1.0f);
    }

    public void EnableSlowMotion()
    {
        Time.timeScale = slowdownFactor;
        Time.fixedDeltaTime = Time.timeScale * 0.02f;
    }
}
