﻿/*
Author: LTDesigns
Date: 4/9/2017
Purpose: This script is used to instantiate a physics based explosion.
*/

using UnityEngine;
using System.Collections;

public class Explosion : MonoBehaviour {

    [SerializeField]
    private float radius = 2.0f; // How wide we want our explosion to be
    [SerializeField]
    private float power = 2.0f; // How powerful our explosion will be

    private Vector3 explosionPosition;
    
	// Use this for initialization
	void Start () {
        //Set the rotation to original rotation
        transform.rotation = Quaternion.identity;
        //Set the position of the explosion
        explosionPosition = transform.position;
        //Create an array to hold objects hit in the blast radius
        Collider[] colliders = Physics.OverlapSphere(explosionPosition, radius);
        //Go through the colliders in the array
        foreach (Collider hit in colliders)
        {
            Rigidbody rb = hit.GetComponent<Rigidbody>(); // Try to grab the rigidbody from the colliders
            if (rb != null) // If there is a rigidbody
            {
                rb.AddExplosionForce(power, explosionPosition, radius, 3); // Make our explosion happen
            }
        }
        WaitToKill(); // Run our wait method
    }

	
	// Update is called once per frame
	void Update () {
	
	}
    // Used for timer
IEnumerator WaitToKill()
{
    yield return new WaitForSeconds(5.0f); // Wait for 5 seconds
    Destroy(gameObject); // Destroy the explosion
}

}
