﻿/*
Author: LTDesigns
Date: 4/9/2017
Purpose: This script is used for user controlled movement of a gameObject.
This is a basic playerMovement script designed to be easily understood and
added onto. 
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {
    [SerializeField]
    private Rigidbody rb; //We will need the rigidBody attached to the gameObject
    [SerializeField]
    private int moveSpeed; // We need to create a variable to hold the gameObject's movement speed
    [SerializeField]
    private int revMoveSpeed; // We create a second variable to hold reverse speed so we can adjust them serparately
    [SerializeField]
    private float rotationSpeed; // We need to create a variable to hold the gameObject's rotation speed

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        
    }

    // We use FixedUpdate to maintain frame rates
    private void FixedUpdate()
    {
        // If the user presses the vertical axis (analog, w, up arrow)
        if (Input.GetAxis("Vertical") > 0)
        {
            // MOVE FORWARD
            // Apply force to the gameObject on the transform's forward axis
            rb.AddForce(transform.forward * moveSpeed);
        }
        // If the user presses the vertical axis (analog, s, down arrow)
        if (Input.GetAxis("Vertical") < 0)
        {
            // MOVE BACKWARDS
            // Apply negative force to the gameObject on the transform's forward axis
            rb.AddForce(-transform.forward * revMoveSpeed);
        }
        // If the user presses the horizontal axis (anolog, d, right arrow)
        if(Input.GetAxis("Horizontal") > 0)
        {
            // TURN RIGHT
            // Apply rotation to the gameObject's transform
            transform.Rotate(0, rotationSpeed, 0);
        }
        // If the user presses the horizontal axis (analon, a, left arrow)
        if(Input.GetAxis("Horizontal") < 0)
        {
            // TURN LEFT
            // Apply negative rotation to the gameObject's transform
            transform.Rotate(0, -rotationSpeed, 0);
        }
    } 
}
