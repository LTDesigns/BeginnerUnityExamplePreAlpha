﻿/*
Author: LTDesigns
Date: 4/9/2017
Purpose: This script is used to allow the character to perform certain abilities.
*/

using UnityEngine;
using System.Collections;

public class CharacterAbilityController : MonoBehaviour {

    private LookTeleport lt;
    private SlowMotion sm;
    private SpellSpawner sp;
    private Animator anim;
    private Gravity grav;
	// Use this for initialization
	void Start () {
        sm = GetComponent<SlowMotion>();
        lt = GetComponent<LookTeleport>();
        sp = GetComponentInChildren<SpellSpawner>();
        anim = GetComponent<Animator>();
        grav = GetComponent<Gravity>();
	}
	
	// Update is called once per frame
	void Update () {
	if(Input.GetKeyDown("t"))
        {
            lt.Teleport();
        }
    if(Input.GetKeyDown("g"))
        {
            sm.EnableSlowMotion();
        }
    if(Input.GetAxis("Fire1") > 0)
        {
            anim.SetTrigger("Fireball");
            sp.Fireball();
        }
    if(Input.GetKeyDown("f"))
        {
            grav.EnableGravity();
        }
    if(Input.GetKeyDown("v"))
        {
            grav.DisableGravity();
        }
	}
}
