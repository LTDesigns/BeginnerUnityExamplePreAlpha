﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour {

    [SerializeField]
    private int maxHealth = 100; // We set our maxHealth as SerialzeField so it shows up in the inspector but is still private
    int curHealth; // We need a variable to store our current health in
    public Slider healthSlider; // We need to tell our engine which GUI element to adjust
    private Collider player; // We need a way to find out if we are in contact with something that will hurt us

    private bool canTakeDamage;
    private float invulnerableTimer = 3.0f;
    // Use this for initialization
    void Start () {
        player = GetComponent<CapsuleCollider>(); // Grab out player's character collider
        curHealth = maxHealth; // Set our character's health to our current maxHealth
        healthSlider.value = maxHealth; // We need to update our GUI with our health value
        canTakeDamage = true; // Set it to where we are able to take damage
    }
	
	// Update is called once per frame
	void Update () {
	
	}

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "DamageObject") // If we come in contact with a gameObject with the DamageObject tag         
        {
            if (canTakeDamage == true) // If we can take damage
            {
                TakeDamage(); // Run our TakeDamage() method
            }
            else // We cannot take damage
            {
                return; // Try again
            }
        }
    }

    void TakeDamage()
    {
        curHealth -= 10; // Subtract 10 from our health
        healthSlider.value = curHealth; // Move our GUI slider to show our health falling
        print(curHealth); // Print debug message
        InvulnerableTimer(); // Run our invulnerable method
    }

    // Used for a delay timer
    IEnumerator InvulnerableTimer()
    {
        canTakeDamage = false; // Set our bool value to false, we can no longer take damage.
        print("Can take damage = False"); // Print debug message
        yield return new WaitForSeconds(invulnerableTimer); // Wait for x amount of seconds
        canTakeDamage = true; // Set our bool value to true, we can take damage again.
        print("Can take damage = True"); // Print debug message
    }
}
