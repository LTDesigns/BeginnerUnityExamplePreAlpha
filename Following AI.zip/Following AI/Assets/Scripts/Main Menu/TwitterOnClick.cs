﻿using UnityEngine;
using System.Collections;

public class TwitterOnClick : MonoBehaviour {

	// Use this for initialization
	public void TwitterClick () {
        Application.OpenURL("https://twitter.com/LT_Designs_Ohio");
	}

}
