﻿using UnityEngine;
using System.Collections;

public class QuitOnClick : MonoBehaviour {

	public void Quit()
	{
		#if UNITY_EDITOR
		//If in the editor we go back to the editor
		UnityEditor.EditorApplication.isPlaying = false;
		#else
		//If we're NOT in the editor we close the game
		Application.Quit ();
		#endif
	}
}
