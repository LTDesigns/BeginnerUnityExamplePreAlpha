﻿using UnityEngine;
using System.Collections;

public class MyPause : MonoBehaviour {

   public Transform canvas;





   // Update is called once per frame
   void Update()
   {
      if (canvas.gameObject.activeInHierarchy == true)
      {
         Pause();
      }
      if (canvas.gameObject.activeInHierarchy == false)
      {
         UnPause();
      }
   }
   public void Pause()
   {
      if (canvas.gameObject.activeInHierarchy == true)
      {

         Time.timeScale = 0;

      }
   }

      public void UnPause()
   { 
      if (canvas.gameObject.activeInHierarchy == false)
      {
         Time.timeScale = 1;

      }
   }
}
