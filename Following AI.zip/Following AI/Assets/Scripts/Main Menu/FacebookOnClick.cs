﻿using UnityEngine;
using System.Collections;

public class FacebookOnClick : MonoBehaviour {


	public void FacebookClick () {
        Application.OpenURL("https://www.facebook.com/JacksEscapeAndroid");
	}

}
