﻿using UnityEngine;
using System.Collections;

public class DonateOnClick : MonoBehaviour {

	// Use this for initialization
	public void DonateClick () {
        Application.OpenURL("https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=lukas%2ethompson%40students%2eabtu%2eedu&lc=US&item_name=LTDesigns&item_number=Make%20More%20Games%21&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted");
	}

}
