﻿using UnityEngine;
using System.Collections;

public class YouTubeOnClick : MonoBehaviour {

	// Use this for initialization
	public void YouTubeClick () {
        Application.OpenURL("https://www.youtube.com/channel/UCLhKDfknut3SEDVIi_DCPlA");
	}

}
