﻿/*
Author: LTDesigns
Date: 4/9/2017
Purpose: This script is used to allow the MainCamera to rotate around a gameObject.
We will use this in order to control the camera behind our playerObject.
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{

 
     [SerializeField]
    private Transform target; // The object we want the camera to follow

    [SerializeField]
    private Vector3 offsetPosition; // The camera offset, should be something like: (0,1,-3)

    [SerializeField]
    private Space offsetPositionSpace = Space.Self; // What spacial environment we wish to use, local or world

    [SerializeField]
    private bool lookAt = true; // Are we looking at the object

    private void Update()
    {
        // Check the camera positions
        Refresh();
    }

    public void Refresh()
    {
        // If the user did not set a target to follow
        if (target == null)
        {
            // Display a warning message to the user
            Debug.LogWarning("Missing target object ", this);
            return;
        }

        // Compute the position of the camera
        // If we are using local space
        if (offsetPositionSpace == Space.Self)
        {
            // Transform based off of our own space
            transform.position = target.TransformPoint(offsetPosition);
        }
        // If we are using world space
        else
        {
            // Transform based off of world space
            transform.position = target.position + offsetPosition;
        }

        // Compute the rotation of the camera
        // If we are looking at the gameObject
        if (lookAt)
        {
            // Rotate around the target
            transform.LookAt(target);
        }
        // If we are not looking at the target
        else
        {
            // Rotate around the target's rotation
            transform.rotation = target.rotation;
        }
    }
}
