﻿/*
Author: LTDesigns
Date: 4/9/2017
Purpose: This script is used to allow one gameObject move towards another gameObject.
In the following scenarios we will use this basic AI script in order to have enemies
chase our player character, as well as use the script for a companion.
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowAI : MonoBehaviour
{
    [SerializeField]
    private Transform player;  // Target our gameObject will follow
    [SerializeField]
    private float trackingDistance = 30.0f; // How far ahead our gameObject can see 
    [SerializeField]
    private float lookSpeed = 5.0f; // How fast our gameObject will rotate
    [SerializeField]
    private float stopDistance = 3.0f; // How far from our Target will our gameObject stop
    [SerializeField]
    private float moveSpeed = 0.05f; // How fast our gameObject can move
    [SerializeField]
    private float lookAngle = 130.0f; // The radius our gameObject is able to see, our CONE of vision. 
    private Animator anim; // We will need the Animator component attached to our gameObject (Used if your character has animations)

    // Use this for initialization
    void Start()
    {
        // Grab the Animator attached to our gameObject
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        // Find the direction we wish to look at
        Vector3 direction = player.position - this.transform.position;
        // Find the angle of our gameObject
        float angle = Vector3.Angle(direction, this.transform.forward);
        // If the distance to our Target is less than our trackingDistance
        if (Vector3.Distance(player.position, this.transform.position) < trackingDistance && angle < lookAngle)
        {
            // Freeze the y axis to prevent our gameObject from moving vertically
            direction.y = 0;
            // Turn our gameObject to look at our target
            this.transform.rotation = Quaternion.Slerp(this.transform.rotation, Quaternion.LookRotation(direction), lookSpeed * Time.deltaTime);
            // If our gameObject is farther than our designated stopDistance
            if (direction.magnitude > stopDistance)
            {
                // Move our gameObject towards our Target, until we reach our stopDistance
                this.transform.Translate(0, 0, moveSpeed);
                // Set our Walking parameter on our Animator to true, plays our walking animation
                // anim.SetBool("Running", true); used if a character has animations
            }
            else
            {
                // Set our Walking parameter on our Animator to false, plays our default Animator state(idle)
                // anim.SetBool("Running", false); used if a character has animations
            }
        }
    }
}

